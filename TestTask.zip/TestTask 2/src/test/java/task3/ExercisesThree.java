package task3;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class ExercisesThree {
    WebDriver driver;

    @Test
    void switchTabs() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://freegeoip.io/");
        clickGetFreeButton();
        // After clicking, the switchTab method is used to change the page
        switchTab(1);
        assertEquals(driver.getCurrentUrl(), "https://ipstack.com/", "Page doesn't changed");

        driver.quit();
    }

    private void clickGetFreeButton() {
        WebElement getFreeButton = driver.findElement(By.cssSelector("[class='go']"));
        //Use of the hotkeys page doesn't change(because when  click on the button, the page changes automatically)
        new Actions(driver).keyDown(Keys.COMMAND)
                .click(getFreeButton)
                .build()
                .perform();
    }

    // This method works dynamically and when we have multiple tabs we can choose which tab we want to get
    public void switchTab(int index) {
        List<String> windowHandles = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(windowHandles.get(index));
    }
}
