package task1;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ExercisesOne {

    @Test
    void exercisesOne() {
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://kivork.md/");

        //1. If an element is not attached to DOM then we could try using the try-catch block within for loop
        for (int i = 0; i < 2; i++) {
            try {
                driver.manage().window().maximize();
                WebElement w = driver.findElement(By.xpath("//*[@id='menu-header-1']/li[2]/a"));
                w.click();
                driver.navigate().back();
                w.click();
                break;
            } catch (StaleElementReferenceException e) {
                System.out.println(e.getMessage());
            }
        }

        //2. We could refresh the page and try again for the same element.
        driver.navigate().refresh();
        driver.findElement(By.xpath("//*[@id='menu-header-1']/li[2]/a")).click();
    }
}
