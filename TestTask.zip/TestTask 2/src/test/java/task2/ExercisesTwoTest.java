package task2;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import pojos.MainPojo;

import java.util.Arrays;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;


public class ExercisesTwoTest {

    @BeforeClass
    public void beforeClass() {
        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder();
        requestSpecBuilder.setBaseUri("http://api.ipstack.com")
                .addQueryParam("access_key", "f64b830bb09ded38f1d3d5f90e4b8dfd");
        RestAssured.requestSpecification = requestSpecBuilder.build();
    }

    @Test
    public void assertTheResponseCode() {
        Response response = get("/5.63.165.163")
                .then()
                .extract()
                .response();
        assertThat(response.statusCode(), (equalTo(200)));
    }


    @Test
    public void parseTheResponse() throws JsonProcessingException {
        MainPojo parseMainPojo = given().body(new MainPojo())
                .when().get("/5.63.165.163")
                .then().log().all().extract().response().as(MainPojo.class);
        ObjectMapper objectMapper = new ObjectMapper();

        System.out.println("Deserialization" + " " + objectMapper.writeValueAsString(parseMainPojo));
    }

    @Test
    public void assertYourLatitudeAndLongitude() {
        MainPojo parseMainPojo = given().body(new MainPojo())
                .when().get("/5.63.165.163")
                .then().extract().response().as(MainPojo.class);

        double latitude = parseMainPojo.getLatitude();
        double longitude = parseMainPojo.getLongitude();

        SoftAssert softAssert = new SoftAssert();

        softAssert.assertEquals(Arrays.toString(dMSFormula(latitude)).replace("[", "").replace("]", ""), "40, 16, 26", "latitude is wrong");
        softAssert.assertEquals(Arrays.toString(dMSFormula(longitude)).replace("[", "").replace("]", ""), "45, -22, -28", "longitude is wrong ");

        softAssert.assertAll();
    }

    //expresses latitude and longitude in degrees, minutes and seconds using this formula
    private int[] dMSFormula(double value) {

        int degrees = (int) Math.round(value);
        double d = value - degrees;
        double m = d * 60;

        int minutes = (int) Math.round(m);
        double s = m - minutes;
        double c = s * 60;

        int seconds = (int) Math.round(c);

        return new int[]{degrees, minutes, seconds};
    }

}
